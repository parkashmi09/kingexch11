---
name: port-cra-to-vite
description: Use when porting any code from old-code/d99-frontend (Create React App) or old-code/d99-admin into the new apps (Vite). Codifies the exact rewrites that must happen so the ported file compiles and behaves correctly under Vite.
---

# Port old code → Vite

The legacy client app under `old-code/d99-frontend` is **Create React App**.
The legacy admin under `old-code/d99-admin` is already Vite but may have
patterns to clean up. The new apps under `tenexch/frontend/` and `tenexch/admin/`
are **Vite**. Apply every rewrite below when porting a file.

## Required rewrites (CRA → Vite)

| CRA                                          | Vite                                              |
|----------------------------------------------|---------------------------------------------------|
| `process.env.REACT_APP_API_URL`              | `import.meta.env.VITE_API_URL`                    |
| `process.env.REACT_APP_SOCKET_URL`           | `import.meta.env.VITE_SOCKET_URL`                 |
| `process.env.NODE_ENV === "development"`     | `import.meta.env.DEV`                             |
| `process.env.PUBLIC_URL`                     | `import.meta.env.BASE_URL` (usually `/`)          |
| `import logo from "./logo.png"`              | `import logo from "./logo.png"` *(works the same)*|
| `import("./Foo")` lazy                       | works the same                                    |
| `react-scripts start`                        | `vite`                                            |
| `react-scripts build`                        | `vite build`                                      |
| Tests via `react-scripts test`               | not ported — tests are out-of-scope for now       |
| SVG as React component (`{ ReactComponent }`)| use `vite-plugin-svgr` *or* import as URL string  |

## Service-layer rewrites

Every API service in the old code does `import axios from 'axios'` directly and
pulls the token from `localStorage` inside each function. **Do not port that
pattern.** Instead:

```js
// src/apiservices/AuthService.js
import api from "./axiosClient";

export const loginUser = (credentials) =>
  api.post("/user/login", credentials).then((r) => r.data);
```

The shared `axiosClient.js` already:
- prepends `VITE_API_URL`
- attaches `Authorization: Bearer <token>` from `localStorage`
- handles 401 → redirect to `/login`

So service files become 2-3 lines each.

## File extensions

- React components → `.jsx` (not `.js`)
- Pure modules / services / utils → `.js`
- TypeScript not in use yet — keep porting in JS.

## Checklist for each ported file

- [ ] All `process.env.REACT_APP_*` rewritten
- [ ] No raw `import axios from "axios"` left
- [ ] Imports use `@/...` alias when crossing top-level folders
- [ ] New `VITE_*` env vars added to `.env.example`
- [ ] `npm run build` from the target app succeeds
