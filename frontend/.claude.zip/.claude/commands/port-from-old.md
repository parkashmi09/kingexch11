---
description: Port a file or feature from old-code into the new Vite project
allowed-tools: Read, Write, Edit, Glob, Grep, Bash
argument-hint: <client|admin> <relative path inside old-code src/>
---

Use the `api-porter` subagent to translate the file from old code into the
equivalent location under the target app's `src/`, rewriting CRA-isms
(`process.env.REACT_APP_*` → `import.meta.env.VITE_*`, raw axios → shared
`axiosClient`, etc.).

Source paths:
- client: `old-code/d99-frontend/src/$ARGUMENTS`
- admin: `old-code/d99-admin/src/$ARGUMENTS`

Also port any direct dependencies of that file so the new file compiles, and
update the target `.env.example` if any new `VITE_*` env vars were introduced.
