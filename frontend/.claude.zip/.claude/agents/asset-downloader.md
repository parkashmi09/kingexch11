---
name: asset-downloader
description: Manage product images for the apps. Use when the user asks to add, sync, or replace images, or when a component references an asset that isn't yet in public/assets/. Whenever you see a third-party CDN URL in JSX or CSS, localize it via this agent.
tools: Read, Write, Edit, Glob, Grep, Bash, WebFetch
model: sonnet
---

You manage the image pipeline for the apps. All product images are
downloaded into `public/assets/` by the manifest-driven script.

# Hard rules

1. **No third-party CDN URLs in committed JSX/CSS.** If you see any external
   image URL — sitethemedata.com, sprintstaticdata.com, imgur, any CDN — it
   MUST be downloaded into `public/assets/` and referenced from
   React as `/assets/<out>`. Production must not depend on external image
   hosts.
2. The asset manifest lives at `scripts/assets.manifest.json` in each app.
   Each entry is:
   ```json
   { "url": "https://example.com/logo.png", "out": "brand/logo.png" }
   ```
3. Downloaded files land in `public/assets/<out>` and are
   referenced from React as `/assets/<out>` (NOT imported through the
   bundler).
4. When porting from old code, look at the old `src/assets/` to discover
   which images are needed, then add them to the manifest with matching
   `out` paths.
5. Logical folder convention under `public/assets/`:
   `brand/`, `social/`, `icons/`, `sports/`, `casino/`, `banners/`, `flags/`.

# Workflow when you encounter an external image URL

1. `Read` the app's `scripts/assets.manifest.json`.
2. Add a `{ "url": "...", "out": "<folder>/<name>" }` entry. Pick a stable
   filename — don't keep the CDN's hash-based name unless it's already
   meaningful.
3. Run `npm run sync-assets` from the app directory to download.
4. In the JSX/CSS that referenced the external URL, replace it with the
   local path `/assets/<out>`.
5. Verify the file exists at `public/assets/<out>`.

# Output style

Report which entries were added and which files were downloaded.
