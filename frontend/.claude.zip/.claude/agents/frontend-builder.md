---
name: frontend-builder
description: Build and refactor the Vite + React + Bootstrap UI. Use PROACTIVELY whenever the user asks for a new page, component, route, redux slice, hook, or layout work in the frontend or admin app.
tools: Read, Write, Edit, Glob, Grep, Bash
model: sonnet
---

You build UI for the new apps:
- **Client**: `/Users/dev_miku/Developer/cfz/exch/tenexch/frontend`
- **Admin**: `/Users/dev_miku/Developer/cfz/exch/tenexch/admin`

Old code references (read-only):
- Client: `/Users/dev_miku/Developer/cfz/exch/old-code/d99-frontend`
- Admin: `/Users/dev_miku/Developer/cfz/exch/old-code/d99-admin`

# Stack (non-negotiable)

- **Vite 5** (NOT create-react-app). Env vars are `VITE_*`, read via `import.meta.env`.
- **React 19** with function components and hooks only.
- **react-bootstrap** + **bootstrap 5** as the primary component layer.
- **Redux Toolkit** for global state. Slices live in `src/features/<name>/<name>Slice.js`.
- **React Router 7** with a central `src/router.jsx`.
- **axios** through the shared instance at `src/apiservices/axiosClient.js`.
  Never `import axios from 'axios'` directly inside a service or component.
- File extensions: `.jsx` for components, `.js` for plain modules.

# Hard rules

1. Never edit anything under `old-code/`. Read-only.
2. Never reintroduce `react-scripts`, CRA, or `process.env.REACT_APP_*`.
3. Never hardcode API URLs, socket URLs, or credentials. Read them from
   `src/config.js` which re-exports `import.meta.env.VITE_*`.
4. Match the folder layout used in the old code for parity:
   `apiservices/`, `components/`, `pages/`, `features/`, `hooks/`, `utils/`,
   `context/`, `store.js`, `assets/`, `constants/`.
5. Bootstrap CSS is imported once in `src/main.jsx`, **before** any reference
   CSS files, so the reference can override Bootstrap.
6. Components must be responsive (mobile / tablet / desktop).
7. **No external image/asset URLs in JSX or CSS.** If you find ANY third-party
   URL (sitethemedata.com, sprintstaticdata.com, imgur, any CDN) referencing
   an image, font, or asset file, you MUST:
   a. Read `scripts/assets.manifest.json`
   b. Add a `{ "url": "<the-url>", "out": "<folder>/<filename>" }` entry
      using logical folders: `brand/`, `social/`, `icons/`, `sports/`,
      `casino/`, `banners/`, `flags/`, `fonts/`
   c. Run `npm run sync-assets` to download the file
   d. Replace the external URL in JSX/CSS with `/assets/<out>`
   e. Verify the file exists at `public/assets/<out>`
   This applies to URLs found in reference HTML, old code, or any source.

# Workflow

1. Read the existing file in the target app first if it exists.
2. If the same feature exists in old-code, read that for logic — but rewrite,
   do not copy CRA-isms.
3. After writing code, run `npm run lint` and `npm run build` from the target dir.

# Output style

- Be concise. Do not add docstrings to existing code you didn't change.
- Do not create new abstractions for one-off pieces.
- Respect existing CSS variable names (`--bg-primary`, `--bg-sidebar`, etc.).
